#!/usr/bin/env python3
"""
Analyze if Kakuro Chapter 2, Diagram 2 fits on one page for KDP printing
"""

# Diagram dimensions
diagram_width_px = 1200
diagram_height_px = 4930

# Print resolution
dpi = 300

# Calculate physical dimensions in inches
diagram_width_inches = diagram_width_px / dpi
diagram_height_inches = diagram_height_px / dpi

print("=" * 70)
print("DIAGRAM 2 SIZE ANALYSIS FOR KDP PRINTING")
print("=" * 70)
print()

print(f"📐 DIAGRAM DIMENSIONS:")
print(f"   Pixels: {diagram_width_px} × {diagram_height_px} px")
print(f"   Physical size at 300 DPI: {diagram_width_inches:.2f}\" × {diagram_height_inches:.2f}\"")
print()

# KDP trim sizes
trim_sizes = {
    "8.5\" × 11\" (Letter)": (8.5, 11),
    "8\" × 10\"": (8, 10),
    "7\" × 10\"": (7, 10),
    "6\" × 9\"": (6, 9)
}

# Standard margins for print books (in inches)
# For large print books, we typically use larger margins
margin_top = 0.5
margin_bottom = 0.5
margin_left = 0.75
margin_right = 0.75

print("=" * 70)
print("COMMON KDP TRIM SIZES ANALYSIS")
print("=" * 70)
print(f"Standard margins: Top/Bottom: {margin_top}\", Left/Right: {margin_left}\"")
print()

results = []

for name, (width, height) in trim_sizes.items():
    printable_width = width - margin_left - margin_right
    printable_height = height - margin_top - margin_bottom
    
    width_fits = diagram_width_inches <= printable_width
    height_fits = diagram_height_inches <= printable_height
    
    # Calculate scaling factor if needed
    width_scale = printable_width / diagram_width_inches
    height_scale = printable_height / diagram_height_inches
    min_scale = min(width_scale, height_scale)
    
    # Calculate how many pages needed if splitting vertically
    pages_needed = (diagram_height_inches / printable_height)
    
    print(f"📄 {name}:")
    print(f"   Page size: {width}\" × {height}\"")
    print(f"   Printable area: {printable_width:.2f}\" × {printable_height:.2f}\"")
    print(f"   Width fits: {'✅ YES' if width_fits else '❌ NO'}")
    print(f"   Height fits: {'✅ YES' if height_fits else '❌ NO'}")
    
    if not height_fits:
        print(f"   ⚠️  Diagram is {diagram_height_inches - printable_height:.2f}\" too tall")
        print(f"   📊 Would need ~{int(pages_needed) + 1} pages to fit")
        print(f"   🔍 Scale factor to fit on 1 page: {min_scale:.1%}")
        
        # Calculate readability impact
        if min_scale < 0.5:
            print(f"   ⚠️  WARNING: {min_scale:.1%} scale would be too small for 50-70 age group!")
        elif min_scale < 0.7:
            print(f"   ⚠️  CAUTION: {min_scale:.1%} scale may be challenging for target audience")
        else:
            print(f"   ✅ {min_scale:.1%} scale should still be readable")
    else:
        print(f"   ✅ FITS ON ONE PAGE!")
    
    print()
    
    results.append({
        'name': name,
        'fits': width_fits and height_fits,
        'pages_needed': pages_needed,
        'scale': min_scale
    })

print("=" * 70)
print("RECOMMENDATIONS")
print("=" * 70)
print()

# Find best trim size
best_option = max(results, key=lambda x: x['scale'])

print(f"🎯 RECOMMENDED TRIM SIZE: {best_option['name']}")
print()

if diagram_height_inches > 10:
    print("⚠️  CRITICAL FINDING:")
    print(f"   The diagram is {diagram_height_inches:.2f}\" tall (16.43 inches!)")
    print(f"   This is TOO TALL for any standard KDP trim size to fit on one page.")
    print()
    
    print("📋 YOUR OPTIONS:")
    print()
    
    print("OPTION A: Split Across 2 Pages (RECOMMENDED)")
    print("   ✅ Maintains large print size for target audience")
    print("   ✅ No loss of readability")
    print("   ✅ Professional look with page break")
    print("   • Split between Grid 2 and Grid 3 (roughly halfway)")
    print("   • Add 'Continued on next page...' caption")
    print("   • Repeat the key/legend on second page if needed")
    print()
    
    print("OPTION B: Split Across 3 Pages (ALTERNATIVE)")
    print("   ✅ Even more comfortable reading")
    print("   ✅ Each page shows 1-2 grids clearly")
    print("   • Page 1: Introduction + Grids 1-2")
    print("   • Page 2: Grids 3-4")
    print("   • Page 3: Grid 5 + Summary")
    print()
    
    print("OPTION C: Redesign to Horizontal Layout")
    print("   ✅ Could fit on 1-2 pages")
    print("   ⚠️  Requires redesigning the 5 grids")
    print("   • Arrange grids in 2×3 or 3×2 layout")
    print("   • Show progression with arrows horizontally")
    print()
    
    print("OPTION D: Scale Down (NOT RECOMMENDED)")
    pages_8_5x11 = (8.5, 11)
    printable_8_5x11 = (pages_8_5x11[0] - margin_left - margin_right, 
                        pages_8_5x11[1] - margin_top - margin_bottom)
    scale_needed = printable_8_5x11[1] / diagram_height_inches
    print(f"   ❌ Would need to scale to {scale_needed:.1%} of original size")
    print(f"   ❌ Text would become too small for 50-70 age group")
    print(f"   ❌ Defeats purpose of large print format")
    print()

print("=" * 70)
print(f"✅ FINAL RECOMMENDATION: Split across 2 pages (Option A)")
print("=" * 70)

