from PIL import Image
import os

# Open the full page screenshot
img = Image.open('/home/ubuntu/kakuro_diagrams/full_page.png')
width, height = img.size

print(f"Full image size: {width}x{height}")

# Define approximate positions for each diagram (will need to adjust based on actual layout)
# We'll scan the image to find diagram boundaries by looking for large white spaces

# Convert to RGB if needed
if img.mode != 'RGB':
    img = img.convert('RGB')

# Find diagram boundaries by scanning for content
def find_content_blocks(img, min_gap=100):
    """Find vertical positions where content blocks are separated by white space"""
    width, height = img.size
    
    # Sample the middle column to find white gaps
    content_rows = []
    in_content = False
    start_row = 0
    
    for y in range(height):
        # Check if this row has significant content (not all white)
        has_content = False
        for x in range(0, width, 50):  # Sample every 50 pixels
            r, g, b = img.getpixel((x, y))
            if r < 250 or g < 250 or b < 250:  # Not pure white
                has_content = True
                break
        
        if has_content and not in_content:
            # Start of content block
            start_row = y
            in_content = True
        elif not has_content and in_content:
            # End of content block
            if y - start_row > 50:  # Minimum height for a diagram
                content_rows.append((start_row, y))
            in_content = False
    
    # Add last block if still in content
    if in_content:
        content_rows.append((start_row, height))
    
    return content_rows

# Find all content blocks
blocks = find_content_blocks(img)
print(f"Found {len(blocks)} content blocks")

# Export each block as a separate image
output_dir = '/home/ubuntu/kakuro_diagrams'
for i, (start_y, end_y) in enumerate(blocks, 1):
    # Add some padding
    padding = 20
    start_y = max(0, start_y - padding)
    end_y = min(height, end_y + padding)
    
    # Crop the diagram
    diagram = img.crop((0, start_y, width, end_y))
    
    # Save with descriptive name
    output_path = f'{output_dir}/diagram_{i}.png'
    diagram.save(output_path, 'PNG', optimize=True)
    print(f"Exported Diagram {i}: {output_path} (height: {end_y - start_y}px)")

print(f"\nAll diagrams exported to {output_dir}/")
