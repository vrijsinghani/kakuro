#!/usr/bin/env python3
"""
Split Kakuro Chapter 2, Diagram 2 into two pages for KDP printing.

Original: 1200 × 4930 pixels (16.43" tall at 300 DPI)
Split point: ~2,465 pixels (after Grid 2)
Target: Two pages fitting 8.5" × 11" with margins
"""

from PIL import Image
import os

def split_diagram():
    """Split the diagram into two pages."""
    
    # File paths
    original_path = "/home/ubuntu/kakuro_chapter2_diagrams/diagram_2.png"
    output_dir = "/home/ubuntu/kakuro_chapter2_diagrams"
    page1_path = os.path.join(output_dir, "diagram_2_page1.png")
    page2_path = os.path.join(output_dir, "diagram_2_page2.png")
    
    # Load original image
    print("Loading original diagram...")
    img = Image.open(original_path)
    width, height = img.size
    print(f"Original dimensions: {width} × {height} pixels")
    print(f"Physical size at 300 DPI: {width/300:.2f}\" × {height/300:.2f}\"")
    
    # Split point (after Grid 2)
    split_point = 2465
    
    # Create page 1 (Grids 1-2, top portion)
    print(f"\nCreating Page 1 (top portion, 0 to {split_point})...")
    page1 = img.crop((0, 0, width, split_point))
    page1_width, page1_height = page1.size
    print(f"Page 1 dimensions: {page1_width} × {page1_height} pixels")
    print(f"Page 1 physical size at 300 DPI: {page1_width/300:.2f}\" × {page1_height/300:.2f}\"")
    
    # Save page 1 with high quality
    page1.save(page1_path, "PNG", optimize=False, compress_level=1)
    page1_size = os.path.getsize(page1_path) / 1024
    print(f"Saved to: {page1_path} ({page1_size:.1f} KB)")
    
    # Create page 2 (Grids 3-5, bottom portion)
    print(f"\nCreating Page 2 (bottom portion, {split_point} to {height})...")
    page2 = img.crop((0, split_point, width, height))
    page2_width, page2_height = page2.size
    print(f"Page 2 dimensions: {page2_width} × {page2_height} pixels")
    print(f"Page 2 physical size at 300 DPI: {page2_width/300:.2f}\" × {page2_height/300:.2f}\"")
    
    # Save page 2 with high quality
    page2.save(page2_path, "PNG", optimize=False, compress_level=1)
    page2_size = os.path.getsize(page2_path) / 1024
    print(f"Saved to: {page2_path} ({page2_size:.1f} KB)")
    
    # Check if images fit on 8.5" × 11" pages with margins
    print("\n" + "="*60)
    print("PAGE FIT ANALYSIS FOR 8.5\" × 11\" TRIM SIZE")
    print("="*60)
    
    # Standard margins for KDP
    page_width = 8.5
    page_height = 11.0
    left_margin = 0.75  # Larger for binding
    right_margin = 0.5
    top_margin = 0.75
    bottom_margin = 0.75
    
    printable_width = page_width - left_margin - right_margin
    printable_height = page_height - top_margin - bottom_margin
    
    print(f"\nPage dimensions: {page_width}\" × {page_height}\"")
    print(f"Margins: Left={left_margin}\", Right={right_margin}\", Top={top_margin}\", Bottom={bottom_margin}\"")
    print(f"Printable area: {printable_width}\" × {printable_height}\"")
    
    # Check Page 1
    page1_physical_width = page1_width / 300
    page1_physical_height = page1_height / 300
    page1_fits = (page1_physical_width <= printable_width and 
                  page1_physical_height <= printable_height)
    
    print(f"\n📄 PAGE 1 (Grids 1-2):")
    print(f"   Size: {page1_physical_width:.2f}\" × {page1_physical_height:.2f}\"")
    print(f"   Fits: {'✅ YES' if page1_fits else '❌ NO'}")
    if page1_fits:
        print(f"   Margin space: Width={printable_width - page1_physical_width:.2f}\", Height={printable_height - page1_physical_height:.2f}\"")
    
    # Check Page 2
    page2_physical_width = page2_width / 300
    page2_physical_height = page2_height / 300
    page2_fits = (page2_physical_width <= printable_width and 
                  page2_physical_height <= printable_height)
    
    print(f"\n📄 PAGE 2 (Grids 3-5):")
    print(f"   Size: {page2_physical_width:.2f}\" × {page2_physical_height:.2f}\"")
    print(f"   Fits: {'✅ YES' if page2_fits else '❌ NO'}")
    if page2_fits:
        print(f"   Margin space: Width={printable_width - page2_physical_width:.2f}\", Height={printable_height - page2_physical_height:.2f}\"")
    
    # Overall status
    print("\n" + "="*60)
    if page1_fits and page2_fits:
        print("✅ SUCCESS: Both pages fit within printable area!")
        print("   Ready for KDP upload at 300 DPI.")
    else:
        print("⚠️  WARNING: One or more pages exceed printable area.")
        print("   Consider scaling or adjusting margins.")
    print("="*60)
    
    return {
        'page1': {
            'path': page1_path,
            'dimensions': (page1_width, page1_height),
            'physical_size': (page1_physical_width, page1_physical_height),
            'fits': page1_fits
        },
        'page2': {
            'path': page2_path,
            'dimensions': (page2_width, page2_height),
            'physical_size': (page2_physical_width, page2_physical_height),
            'fits': page2_fits
        }
    }

if __name__ == "__main__":
    result = split_diagram()
    print("\n✨ Diagram split completed successfully!")
